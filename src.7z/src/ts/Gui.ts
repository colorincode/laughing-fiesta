import GUI from 'lil-gui'

export const gui = new GUI()
gui.close()
