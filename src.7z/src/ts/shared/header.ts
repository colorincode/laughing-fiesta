
class header {
    constructor() {
        
    }
}

new header() 
console.log("header module loaded");
