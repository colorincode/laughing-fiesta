console.log("module loaded");


// export function modal () {
//       // const modal = new Modal();
//       let overlay = document.querySelector('.modal-overlay') as HTMLElement;
//       function open() {
//         overlay.classList.remove('is-hidden');
//       }
    
//       function close() {
//         overlay.classList.add('is-hidden');
//       }
//       // let modal.overlay = overlay;
//       const closeButton = overlay.querySelector('.button-close') as HTMLElement;
//       closeButton.addEventListener('click', modal.bind(close));
//       overlay.addEventListener('click', e => {
//         if (closeButton.id === overlay.id) {
//           close();
//         }
//       });
//     return overlay
    
// }
  // const modal = new Modal(document.querySelector('.modal-overlay'));
  // window.openModal = modal.open.bind(modal);
  // window.openModal();